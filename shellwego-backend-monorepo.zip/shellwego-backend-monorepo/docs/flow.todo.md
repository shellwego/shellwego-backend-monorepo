
spot in agent tests/ or firecracker crate for any misalignments, fake implementations, stubs, placeholders.. everything that deviate from root readme.md... we need real production ready 


spot in agent and firecracker crate for any misalignments, fake implementations, stubs, placeholders.. everything that deviate from root readme.md... we need real production ready

===

lets make crates/shellwego-agent production ready by

1. making all test pass, no mock, real verify implementation
2. achieve the purpose as readme.md. no stub, no placeholders, all real no mock, no fake

Your Bible is readme.md in root for any troubles.

response me in many parts... now give me the 1/x part first

===

done working on : crates/shellwego-core , crates/shellwego-storage , crates/shellwego-network

now continue below task...

____/

lets make crates/shellwego-agent production ready by

finishing boilerplate of the src/
making that crate cargo crates/shellwego-agent build having no problems, not root.
Your Bible is readme.md in root for any troubles
______/


oh the latest progress report see docs/changes/agent_production_ready_progress.md
also why not use https://github.com/firecracker-microvm/firecracker or context7 mcp

===
 
lets make crates/shellwego-agent production ready by 

1. finishing boilerplate of the src/
2. making the crate cargo build having no problems

===

Give me the most comprehensive rust (e2e, integration, unit) test cases plan for crates/shellwego-agent . Everything should be real no mock. Make sure easily to run test in single Ubuntu vps... Your plan should be considered as production ready to proof that readme.md purpose achieved

---

Give me scaffolding skeletons diff patch test files In crates/shellwego-agent/tests/[unit/e2e/integration]/[category] based on the plan in tests/ md docs

===

Give me diff patches for 7. Missing "Sovereign" Safety . how many parts? Give me the 1/x first

Understand readme.md then spot any misalignment, non DRYness etc in codebase. Note; we are in skeletons scaffolding phase with //TODOs comments across methods ... Make sure to mentions corresponding paths files while explaining 

===

Execute biggest win number 2 of lib.guide.md ... Make sure you are producing skeletons scaffolding without any logic code. Just //TODO commentd of methods

===

Execute biggest win number 1 of lib.guide.md ... Make sure you are producing skeletons scaffolding without any logic code. Just //TODO commentd of methods
===

understand the readme.md then make sure the codebase boilerplate is enough to achieve the purpose. rules: you are at scaffolding with //TODO phase only. should not write logic. only yhe skeletons

---

send me all the skeletons files of ⚠️ Missing Scaffolding (Structural Gaps) without logic in 6 parts, only with scaffolding //TODOs comments of method. with below format precisely for auto-Script to split code blocks into their correct file paths.

---

**`test/file.txt`**
```
Hello, World!
This is test content.
```

---

**`another/file.rs`**
```rust
fn main() {
    println!("Hello");
}
```

now give me 1/6
